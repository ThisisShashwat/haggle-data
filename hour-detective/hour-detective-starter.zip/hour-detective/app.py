"""Hour Detective, the playable version: type in a few numbers about a project, get its hours.

Run train_app_model.py first to make model.joblib, then: python app.py
Hosts run it with: gunicorn app:app
"""
from pathlib import Path

import joblib
import numpy as np
from flask import Flask, render_template_string, request

saved = joblib.load(Path(__file__).with_name("model.joblib"))
MODEL, COLUMNS = saved["model"], saved["columns"]

PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hour Detective</title>
<style>
  :root { color-scheme: light dark; --ink: #1d1d1f; --soft: #6e6e73; --line: #d2d2d7; --bg: #fbfbfd; --accent: #ec3750; }
  @media (prefers-color-scheme: dark) { :root { --ink: #f5f5f7; --soft: #a1a1a6; --line: #424245; --bg: #111113; } }
  body { margin: 0; min-height: 100vh; display: grid; place-items: center; background: var(--bg); color: var(--ink); font: 16px/1.5 system-ui, sans-serif; }
  main { width: min(380px, 100% - 32px); padding: 32px 0; }
  h1 { margin: 0; font-size: 28px; }
  p { margin: 4px 0 24px; color: var(--soft); }
  label { display: block; margin-bottom: 14px; font-size: 14px; color: var(--soft); }
  input { display: block; width: 100%; box-sizing: border-box; margin-top: 4px; padding: 10px 12px; border: 1px solid var(--line); border-radius: 8px; background: transparent; color: var(--ink); font: inherit; }
  button { width: 100%; margin-top: 8px; padding: 12px; border: 0; border-radius: 8px; background: var(--accent); color: #fff; font: inherit; font-weight: 600; cursor: pointer; }
  output { display: block; margin-top: 28px; text-align: center; font-size: 40px; font-weight: 700; }
  output small { display: block; font-size: 14px; font-weight: 400; color: var(--soft); }
</style>
</head>
<body>
<main>
  <h1>Hour Detective</h1>
  <p>How long did a project take? Enter a few numbers from its GitHub repo.</p>
  <form method="post">
    {% for column, label in columns.items() %}
    <label>{{ label }}<input type="number" name="{{ column }}" min="0" step="any" value="{{ request.form.get(column, '') }}" required></label>
    {% endfor %}
    <button>Guess the hours</button>
  </form>
  {% if hours is not none %}
  <output>{{ "%.1f"|format(hours) }} hours<small>my model's guess</small></output>
  {% endif %}
</main>
</body>
</html>"""

app = Flask(__name__)


def predict_hours(values):
    """The model learned the log of the hours, so turn its answer back into hours."""
    return max(float(np.expm1(MODEL.predict([values])[0])), 0)


@app.route("/", methods=["GET", "POST"])
def home():
    values = [request.form.get(column, type=float) for column in COLUMNS]
    hours = predict_hours(values) if request.method == "POST" and None not in values else None
    return render_template_string(PAGE, columns=COLUMNS, hours=hours)


if __name__ == "__main__":
    app.run(debug=True)
