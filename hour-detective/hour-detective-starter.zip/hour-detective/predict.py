"""Hour Detective: guess how many hours each project took.

We run this file when you ship. It reads train.csv and test.csv from this folder
and writes predictions.csv. Try it yourself with: python predict.py
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

LABELS = ["hours_spent", "log_hours", "hours_bucket"]  # the answers: only train.csv has them

if not Path("train.csv").exists():
    sys.exit("Put train.csv from the haggle Data tab next to predict.py, then run it again.")
train = pd.read_csv("train.csv")

if not Path("test.csv").exists():  # when you ship, we give the real test.csv
    sys.exit("No test.csv yet. Run the last cell of starter.ipynb to make a practice one, then run this again.")
test = pd.read_csv("test.csv")

# Use every column except the id and the answers.
features = [column for column in train.columns if column not in LABELS + ["project_id"]]

# Text columns (like primary_language) become categories the model understands.
for column in train[features].select_dtypes(exclude="number").columns:
    categories = pd.CategoricalDtype(sorted(set(train[column].dropna()) | set(test[column].dropna())))
    train[column] = train[column].astype(categories)
    test[column] = test[column].astype(categories)

# Learn the log of the hours: being 2 times off then costs the same on small and big projects, like the score.
model = HistGradientBoostingRegressor(categorical_features="from_dtype", random_state=0)
model.fit(train[features], np.log1p(train["hours_spent"]))

hours = np.expm1(model.predict(test[features])).clip(min=0)
pd.DataFrame({"project_id": test["project_id"], "hours_spent": hours.round(2)}).to_csv("predictions.csv", index=False)
print(f"Wrote predictions.csv: {len(test)} projects")
