# Hour Detective

My model for [haggle](https://haggle.hackclub.com) Week 1: it guesses how many hours a software project took.

> **Hackatime is required.** Code in VS Code with Hackatime on: hours it didn't track don't count. Record with [Lapse](https://lapse.hackclub.com) too, as a backup.
>
> **Keep committing.** Commit every 30 minutes while you work. More than 60 minutes of coding without a commit gets your ship disqualified.

## What's here

| File | What it does |
|---|---|
| `starter.ipynb` | Look at the data, train a model, check the score |
| `predict.py` | The file haggle runs: reads `train.csv` and `test.csv`, writes `predictions.csv` |
| `requirements.txt` | The Python packages it needs |

## Run it

1. Put `train.csv` from the haggle Data tab in this folder.
2. `pip install -r requirements.txt`
3. Open `starter.ipynb` in VS Code and press **Run All**. The last cell makes a practice `test.csv`.
4. `python predict.py` writes `predictions.csv`.

## How it works

Replace this with what you built: which columns you used, what you tried, what worked and what didn't, and your score.
