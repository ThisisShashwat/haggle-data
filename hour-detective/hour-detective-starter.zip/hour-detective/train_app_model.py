"""Train the small model behind app.py and save it as model.joblib.

Put train.csv from the haggle Data tab in this folder, then run: python train_app_model.py
Commit model.joblib: your hosted app needs it. It's small, and it isn't the data.
"""
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

# The numbers people type into your app: column in train.csv -> label on the page.
COLUMNS = {
    "lines_of_code": "Lines of code",
    "num_source_files": "Source files",
    "num_commits": "Commits",
    "active_commit_days": "Days with a commit",
    "project_span_days": "Days from first to last commit",
}

if not Path("train.csv").exists():
    sys.exit("Put train.csv from the haggle Data tab next to train_app_model.py, then run it again.")
train = pd.read_csv("train.csv")

# Learn the log of the hours, like predict.py. app.py turns it back into hours.
model = HistGradientBoostingRegressor(random_state=0)
model.fit(train[list(COLUMNS)].to_numpy(), np.log1p(train["hours_spent"]))

joblib.dump({"model": model, "columns": COLUMNS}, "model.joblib")
print(f"Saved model.joblib ({Path('model.joblib').stat().st_size // 1024} KB). Commit it.")
